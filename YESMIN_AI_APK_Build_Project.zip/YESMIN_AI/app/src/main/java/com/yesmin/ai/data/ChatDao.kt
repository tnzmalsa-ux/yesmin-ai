package com.yesmin.ai.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface ChatDao {
    @Insert suspend fun insert(message: ChatMessage)
    @Query("SELECT * FROM chat_messages ORDER BY createdAt ASC") suspend fun latest(): List<ChatMessage>
    @Query("DELETE FROM chat_messages") suspend fun clear()
}
