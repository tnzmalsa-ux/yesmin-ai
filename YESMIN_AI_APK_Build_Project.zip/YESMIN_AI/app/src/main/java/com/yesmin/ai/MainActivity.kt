package com.yesmin.ai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.yesmin.ai.actions.ActionManager
import com.yesmin.ai.ai.GeminiClient
import com.yesmin.ai.data.ChatDatabase
import com.yesmin.ai.data.ChatMessage
import com.yesmin.ai.security.KeyStoreManager
import com.yesmin.ai.voice.VoiceManager
import kotlinx.coroutines.launch

private val Bg = Color(0xFF090B16)
private val Panel = Color(0xFF171D30)
private val Cyan = Color(0xFF55DDF4)
private val Purple = Color(0xFF9A7BFF)
private val Muted = Color(0xFF9BA8C4)

class MainActivity : ComponentActivity() {
    private lateinit var db: ChatDatabase
    private lateinit var keys: KeyStoreManager
    private lateinit var actions: ActionManager
    private lateinit var voice: VoiceManager

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) voice.startListening()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = ChatDatabase.get(this)
        keys = KeyStoreManager(this)
        actions = ActionManager(this)
        voice = VoiceManager(this, onResult = { recognized ->
            recognizedText = recognized
        }, onError = { voiceError = it })
        setContent {
            YesminApp(
                db = db,
                keys = keys,
                actions = actions,
                onListen = {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        voice.startListening()
                    } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                },
                onSpeak = { voice.speak(it) },
                onStopSpeak = { voice.stopSpeaking() },
                getRecognized = { recognizedText },
                getVoiceError = { voiceError }
            )
        }
    }

    private var recognizedText by mutableStateOf("")
    private var voiceError by mutableStateOf("")
    override fun onDestroy() {
        if (::voice.isInitialized) voice.destroy()
        super.onDestroy()
    }
}

private enum class Tab(val title: String, val glyph: String) {
    HOME("Home", "⌂"), CHAT("Chat", "✦"), CODING("Coding", "</>"), SETTINGS("Settings", "⚙")
}

@Composable
private fun YesminApp(
    db: ChatDatabase,
    keys: KeyStoreManager,
    actions: ActionManager,
    onListen: () -> Unit,
    onSpeak: (String) -> Unit,
    onStopSpeak: () -> Unit,
    getRecognized: () -> String,
    getVoiceError: () -> String
) {
    var tab by remember { mutableStateOf(Tab.HOME) }
    var dark by remember { mutableStateOf(true) }
    val scheme = if (dark) darkColorScheme(
        primary = Purple, secondary = Cyan, background = Bg, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    ) else lightColorScheme()
    MaterialTheme(colorScheme = scheme) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column {
                Box(Modifier.weight(1f)) {
                    when (tab) {
                        Tab.HOME -> HomePage(
                            onChat = { tab = Tab.CHAT },
                            onCoding = { tab = Tab.CODING },
                            onListen = onListen,
                            onOpenSettings = { tab = Tab.SETTINGS },
                            actions = actions
                        )
                        Tab.CHAT -> ChatPage(db, keys, onSpeak, onStopSpeak, onListen, getRecognized, getVoiceError)
                        Tab.CODING -> CodingPage(keys)
                        Tab.SETTINGS -> SettingsPage(keys, dark, { dark = it }, actions)
                    }
                }
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    Tab.entries.forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Text(item.glyph) },
                            label = { Text(item.title) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomePage(
    onChat: () -> Unit, onCoding: () -> Unit, onListen: () -> Unit,
    onOpenSettings: () -> Unit, actions: ActionManager
) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("YESMIN AI", color = Cyan, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("Your personal AI assistant", color = Muted, fontSize = 12.sp)
                }
                TextButton(onClick = onOpenSettings) { Text("Settings") }
            }
        }
        item {
            Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Box(
                    Modifier.fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color(0xFF34265F), Panel)))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(136.dp).background(
                                Brush.radialGradient(listOf(Purple, Color(0xFF16536A), Panel)), CircleShape
                            ),
                            contentAlignment = Alignment.Center
                        ) { Text("Y", color = Color.White, fontSize = 66.sp, fontWeight = FontWeight.Light) }
                        Spacer(Modifier.height(16.dp))
                        Text("Hello, I'm Yesmin", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Text("A friendly AI companion, ready to help.", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(onClick = onListen) { Text("🎙 Speak") }
                            OutlinedButton(onClick = onChat) { Text("Open chat") }
                        }
                    }
                }
            }
        }
        item { Text("Quick actions", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionTile("AI Chat", "Talk to Gemini", Modifier.weight(1f), onChat)
                ActionTile("Coding Lab", "Write and debug", Modifier.weight(1f), onCoding)
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Phone assistant", color = Cyan, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { actions.openSettings() }) { Text("Phone settings") }
                        OutlinedButton(onClick = { actions.searchYouTube("music") }) { Text("YouTube") }
                    }
                    Text("Actions open Android apps or search results; playback is not claimed automatically.", color = Muted, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun ActionTile(title: String, desc: String, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(15.dp)) {
            Text(title, color = Cyan, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(desc, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ChatPage(
    db: ChatDatabase, keys: KeyStoreManager, onSpeak: (String) -> Unit, onStopSpeak: () -> Unit,
    onListen: () -> Unit, recognized: () -> String, voiceError: () -> String
) {
    val scope = rememberCoroutineScope()
    val messages = remember { mutableStateListOf<ChatMessage>() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Gemini is ready when an API key is configured in Settings.") }

    LaunchedEffect(Unit) { messages.clear(); messages.addAll(db.chatDao().latest()) }
    LaunchedEffect(recognized()) { if (recognized().isNotBlank()) input = recognized() }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Chat with Yesmin", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(status, color = Muted, fontSize = 10.sp)
            }
            TextButton(onClick = { onStopSpeak() }) { Text("Stop voice") }
        }
        if (voiceError().isNotBlank()) Text(voiceError(), color = Color(0xFFFF9B9B), fontSize = 11.sp)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages) { msg ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.isUser) Arrangement.End else Arrangement.Start) {
                    Card(colors = CardDefaults.cardColors(containerColor = if (msg.isUser) Color(0xFF3B3264) else Panel)) {
                        Text(msg.text, Modifier.padding(12.dp), color = Color.White)
                    }
                }
            }
            if (busy) item { Text("Yesmin is thinking…", color = Cyan) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Type in Hindi or English…") }, maxLines = 4
            )
            Column {
                IconButton(onClick = onListen) { Text("🎙") }
                Button(enabled = !busy, onClick = {
                    val prompt = input.trim()
                    if (prompt.isNotEmpty()) {
                        input = ""
                        busy = true
                        scope.launch {
                            val user = ChatMessage(text = prompt, isUser = true)
                            db.chatDao().insert(user)
                            messages.add(user)
                            val apiKey = keys.getApiKey()
                            val result = if (apiKey.isNullOrBlank()) {
                                "Please add your Gemini API key in Settings → AI Brain. Your message has been saved locally."
                            } else {
                                GeminiClient(apiKey).generate(prompt, keys.getModel().ifBlank { "gemini-2.5-flash" })
                            }
                            val reply = ChatMessage(text = result, isUser = false)
                            db.chatDao().insert(reply)
                            messages.add(reply)
                            status = if (apiKey.isNullOrBlank()) "API key not configured" else "Gemini response received"
                            busy = false
                            onSpeak(result)
                        }
                    }
                }) { Text("Send") }
            }
        }
    }
}

@Composable
private fun CodingPage(keys: KeyStoreManager) {
    var task by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("Describe the code you want to create or debug.") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Coding Lab", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Kotlin · Java · Python · JS · HTML · CSS · C++", color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(task, { task = it }, Modifier.fillMaxWidth(), label = { Text("What should I code or fix?") }, minLines = 3)
        Button(enabled = !busy, onClick = {
            busy = true
            scope.launch {
                val key = keys.getApiKey()
                output = if (key.isNullOrBlank()) "Configure your Gemini API key in Settings first."
                else GeminiClient(key).generate("You are a careful coding tutor. Explain in clear steps. Do not execute code. Task: $task", keys.getModel().ifBlank { "gemini-2.5-flash" })
                busy = false
            }
        }) { Text(if (busy) "Working…" else "Generate / Explain") }
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxSize(), colors = CardDefaults.cardColors(containerColor = Panel)) {
            LazyColumn(Modifier.padding(14.dp)) { item { Text(output, color = Color.White, fontSize = 13.sp) } }
        }
    }
}

@Composable
private fun SettingsPage(keys: KeyStoreManager, dark: Boolean, onDark: (Boolean) -> Unit, actions: ActionManager) {
    var apiKey by remember { mutableStateOf(keys.getApiKey().orEmpty()) }
    var model by remember { mutableStateOf(keys.getModel()) }
    var status by remember { mutableStateOf("API key stays on this device in encrypted preferences.") }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Settings", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("AI Brain · Gemini", color = Cyan, fontWeight = FontWeight.Bold)
                        OutlinedTextField(apiKey, { apiKey = it }, Modifier.fillMaxWidth(), label = { Text("Gemini API key") }, singleLine = true)
                        OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Gemini model ID") }, singleLine = true)
                        Text("Use a model ID available to your API key. Default: gemini-2.5-flash", color = Muted, fontSize = 10.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                keys.saveApiKey(apiKey)
                                keys.saveModel(model.ifBlank { "gemini-2.5-flash" })
                                status = "Saved on this device."
                            }) { Text("Save") }
                            OutlinedButton(onClick = {
                                keys.clearApiKey(); apiKey = ""; status = "API key cleared."
                            }) { Text("Clear key") }
                        }
                        OutlinedButton(onClick = {
                            status = "Testing connection…"
                        }) { Text("Test connection (send a test message from Chat)") }
                        Text(status, color = Muted, fontSize = 11.sp)
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Appearance", color = Cyan, fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Dark theme", Modifier.weight(1f), color = Color.White)
                            Switch(dark, onDark)
                        }
                    }
                }
            }
            item { InfoCard("Voice", "Hindi and English speech recognition and Android text-to-speech are available. Voice requires microphone permission.") }
            item { InfoCard("Personality", "Friendly companion · JARVIS · Coding · Professional. This app is an AI assistant, not a human partner.") }
            item { InfoCard("Phone automation", "App launching and YouTube search use Android intents. Accessibility service is optional and disabled until enabled in Android Settings.") }
            item { InfoCard("Memory & Privacy", "Chat messages are stored locally in Room. Clear chat history in the Chat screen is planned for the next maintenance update.") }
            item { InfoCard("Security", "A key stored on-device can still be extracted from a compromised device. Use a secure backend for production deployments.") }
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Cyan, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(body, color = Muted, fontSize = 12.sp)
        }
    }
}
