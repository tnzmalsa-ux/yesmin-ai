package com.yesmin.ai.accessibility

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Optional service shell. It deliberately performs no taps, text entry, or background actions.
 * The user must explicitly enable it in Android Accessibility settings.
 */
class YesminAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit
}
