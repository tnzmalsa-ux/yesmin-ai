package com.yesmin.ai.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class KeyStoreManager(context: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        context,
        "yesmin_secure_settings",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveApiKey(value: String) { prefs.edit().putString("gemini_api_key", value.trim()).apply() }
    fun getApiKey(): String? = prefs.getString("gemini_api_key", null)
    fun clearApiKey() { prefs.edit().remove("gemini_api_key").apply() }
    fun saveModel(value: String) { prefs.edit().putString("gemini_model", value.trim()).apply() }
    fun getModel(): String = prefs.getString("gemini_model", "gemini-2.5-flash").orEmpty()
}
