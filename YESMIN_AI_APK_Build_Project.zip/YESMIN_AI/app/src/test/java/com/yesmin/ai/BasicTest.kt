package com.yesmin.ai

import org.junit.Assert.assertTrue
import org.junit.Test

class BasicTest {
    @Test fun projectNameIsNotBlank() {
        assertTrue("YESMIN AI".isNotBlank())
    }
}
