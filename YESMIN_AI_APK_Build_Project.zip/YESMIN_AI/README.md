# YESMIN AI

**YESMIN AI** is a single-project native Android AI assistant starter built with Kotlin, Jetpack Compose, Material 3, Room, Android platform APIs, and Google's Gemini API.

This repository is intended to be the one source project for the YESMIN AI Android app. It is a starter implementation, not a finished or production-certified assistant.

## Current features

- Compose dashboard with Home, Chat, Coding Lab, and Settings areas
- Gemini `generateContent` REST client
- User-provided Gemini API key storage using AndroidX Security Crypto
- Editable Gemini model ID
- Local Room chat-message storage
- Android SpeechRecognizer and TextToSpeech integration
- YouTube search/open through Android intents
- Shortcuts for Android Settings, dialer, camera, browser, and launching installed apps
- Optional AccessibilityService declaration; the service is intentionally a no-op and does not control other apps

## Not finished yet

- A real Gemini connection-test screen and automatic model catalogue discovery
- Streaming responses and robust error/retry handling
- Chat deletion, export, and user-approved editable memory
- Full Coding Lab editor and file export
- More complete language, voice, and permission settings
- Functional accessibility actions (currently not implemented)
- Backend proxy for production API-key protection
- Complete automated UI/instrumentation test coverage

Features should be treated as implemented only where the source code actually provides them. Do not assume a feature is complete because it appears in a roadmap.

## Project structure

```text
.
├── .github/workflows/android.yml
├── app/
│   ├── build.gradle.kts
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml
│       │   ├── java/com/yesmin/ai/
│       │   │   ├── MainActivity.kt
│       │   │   ├── accessibility/
│       │   │   ├── actions/
│       │   │   ├── ai/
│       │   │   ├── data/
│       │   │   ├── security/
│       │   │   └── voice/
│       │   └── res/
│       └── test/
├── build.gradle.kts
├── gradle.properties
└── settings.gradle.kts
```

## Requirements

- JDK 17
- Android SDK Platform 36 and Android Build Tools 36
- Gradle 8.13
- Internet access to download Gradle and Maven dependencies

The Android Gradle Plugin and Kotlin versions are declared in the root `build.gradle.kts`. Use the versions in the repository together; do not upgrade one tool independently without checking compatibility.

## Build with Android Studio

1. Install Android Studio and Android SDK Platform 36.
2. Open this repository as an existing project.
3. Allow Gradle sync to finish.
4. Build **Build > Make Project**, or run the Gradle task `assembleDebug`.
5. The expected debug APK output path is:

   `app/build/outputs/apk/debug/app-debug.apk`

No APK is included in this repository because a successful build has not yet been verified.

## Build from a computer terminal

If the repository does not contain a Gradle wrapper yet, generate it once with Gradle 8.13:

```bash
gradle wrapper --gradle-version 8.13
```

Then build:

```bash
./gradlew assembleDebug
```

On Windows use:

```powershell
gradlew.bat assembleDebug
```

## Termux on Android

The project is intended to remain one Android app project, but **Termux is not an officially supported Android Gradle build host**. Android SDK host tools (including AAPT2) may not run correctly in Termux because of host-platform compatibility.

If attempting a Termux build, first confirm your actual Java and SDK paths:

```bash
java -version
echo "$ANDROID_HOME"
echo "$ANDROID_SDK_ROOT"
ls "$ANDROID_HOME/platforms"
ls "$ANDROID_HOME/build-tools"
```

Set the SDK variables to the real SDK directory on your device:

```bash
export ANDROID_HOME="$HOME/android-sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
```

Generate the wrapper if needed and try:

```bash
gradle wrapper --gradle-version 8.13
./gradlew assembleDebug
```

If the build fails because Android SDK host tools cannot execute under Termux, use Android Studio on a supported desktop environment or a CI build (such as the included GitHub Actions workflow). Keep the same repository; do not create a separate app project.

## GitHub: publish this project

Create an empty repository on GitHub, then from the project root run:

```bash
git init
git add .
git commit -m "Initial YESMIN AI Android project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the remote URL with your own GitHub repository URL. Do not commit API keys, signing keys, `local.properties`, or other secrets.

## Gemini API key safety

- Enter your own key in the app's settings; never put it in source code.
- Never commit API keys, screenshots containing keys, signing credentials, or local configuration files.
- A key embedded in a mobile app can potentially be extracted from a compromised device. Encrypted local storage helps protect data at rest but does not make a client-side key production-safe.
- For a public release, route Gemini requests through a secured backend and apply authentication, quotas, and abuse protection.
- Do not run generated code or shell commands automatically.

## Permissions and phone actions

Android permissions and system security controls must not be bypassed. Sensitive actions should require clear user confirmation. The optional accessibility service is currently a placeholder and should remain disabled unless the device owner explicitly enables it in Android settings.

## CI

GitHub Actions is configured to attempt a debug build on pushes and pull requests. A green CI run is the evidence to use for a successful CI build; this archive itself has not been compiled or tested.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). Please report reproducible build errors with the complete error text, Gradle version, Java version, and Android SDK version. Remove API keys and personal information before sharing logs.

## Security reports

See [SECURITY.md](SECURITY.md).
