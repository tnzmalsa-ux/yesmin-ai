# Security policy

## Reporting a vulnerability

Do not publish API keys, access tokens, signing keys, or personal data in an issue. For a private report, use GitHub's **Report a vulnerability** feature if it is enabled for the repository, or contact the repository maintainer through a private channel.

## Project security requirements

- Never hardcode Gemini API keys or commit secrets.
- Treat client-side API keys as extractable; use a secured backend for production.
- Never execute generated code or arbitrary shell commands automatically.
- Do not bypass Android permissions or security controls.
- Require explicit user confirmation for sensitive device actions.
- Keep optional accessibility functionality disabled until the device owner enables it.
