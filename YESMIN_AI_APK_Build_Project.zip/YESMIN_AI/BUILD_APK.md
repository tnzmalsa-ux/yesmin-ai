# Build YESMIN AI into an APK

This repository contains the Android **source project**. It does not contain a prebuilt APK. Build it to create:

`app/build/outputs/apk/debug/app-debug.apk`

## Option A — GitHub Actions (recommended if you only have an Android phone)

1. Create a new, empty GitHub repository.
2. Extract this ZIP and upload the contents of the `YESMIN_AI` folder to the repository's root.
3. Open the repository's **Actions** tab.
4. Select **Android CI** and run it, or push a commit to `main`.
5. Wait for the workflow to finish. A successful run will have an artifact named `yesmin-ai-debug-apk`.
6. Open the completed workflow run, download that artifact, and extract the APK from it.
7. Transfer the APK to your Android phone and install it. Android may ask you to allow installation from the app you used to open the APK.

A failed workflow is not a completed build. Open the failed run's log and share the first meaningful Gradle/Kotlin error (remove any API keys first).

## Option B — Android Studio

1. Open the extracted project folder in Android Studio.
2. Install JDK 17 and Android SDK Platform 36 / Build Tools 36.0.0 if Android Studio requests them.
3. Sync the project.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**, or run `assembleDebug`.
5. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.

## Option C — Termux

Termux is not an officially supported Android Gradle build host. SDK host tools can fail on Android/Termux even when Gradle itself starts correctly.

If Gradle is already installed and your Android SDK is configured, run:

```bash
cd ~/YesminAI
gradle wrapper --gradle-version 8.13
./gradlew assembleDebug
```

If successful, the APK will be at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

If AAPT2 or another Android SDK host binary fails to execute in Termux, use Option A or B. Do not repeatedly change random Gradle versions; share the exact error so the cause can be diagnosed.

## Before sharing or publishing

- Add your Gemini API key only inside the app's settings; never add it to GitHub.
- A client-side API key can be extracted from a compromised device. A backend proxy is recommended before public release.
- This is a debug APK, not a Play Store release build. A release build requires a properly protected signing key and a separate release configuration.
