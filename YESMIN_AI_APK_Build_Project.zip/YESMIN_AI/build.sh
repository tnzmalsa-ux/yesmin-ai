#!/usr/bin/env bash
set -euo pipefail

if [[ -x "./gradlew" ]]; then
  ./gradlew assembleDebug
elif command -v gradle >/dev/null 2>&1; then
  gradle wrapper --gradle-version 8.13
  ./gradlew assembleDebug
else
  echo "Gradle is not installed. Open this project in Android Studio or use the GitHub Actions workflow." >&2
  exit 1
fi

APK="app/build/outputs/apk/debug/app-debug.apk"
if [[ -f "$APK" ]]; then
  echo "APK created: $APK"
else
  echo "Build command finished but APK was not found at $APK" >&2
  exit 2
fi
