# Contributing to YESMIN AI

1. Work in the existing integrated Android project; do not create a parallel app.
2. Keep Kotlin, Android Gradle Plugin, Gradle, compile SDK, and JDK versions compatible.
3. Do not commit API keys, `local.properties`, signing keys, or generated build output.
4. Never execute AI-generated code or arbitrary shell commands automatically.
5. Keep accessibility disabled unless the device owner explicitly enables it.
6. Add or update tests for behavior that can be tested.
7. In pull requests, list changed files, build/test commands, and the actual results. Do not report an unrun test as passing.
8. Keep permissions minimal and explain any new permission in the pull request.
